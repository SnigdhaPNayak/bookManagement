import { Component } from '@angular/core';

@Component({
  selector: 'app-invalid-credentials',
  templateUrl: './invalid-credentials.component.html',
  styleUrls: ['./invalid-credentials.component.css']
})
export class InvalidCredentialsComponent {

}
