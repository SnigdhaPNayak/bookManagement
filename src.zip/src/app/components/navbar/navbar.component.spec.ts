import { ComponentFixture, TestBed } from '@angular/core/testing';
import { NavbarComponent } from './navbar.component';
import { MatIconModule } from '@angular/material/icon';
import { Router } from '@angular/router';
import { RouterTestingModule } from '@angular/router/testing';
import { LocalStorageMock } from 'src/app/services/LocalStorageMock';
import { SessionStorageMock } from 'src/app/services/SessionStorageMock';
import { By } from '@angular/platform-browser';
import { Component } from '@angular/core';

describe('NavbarComponent', () => {

  let component: NavbarComponent;
  let fixture: ComponentFixture<NavbarComponent>;

  let router: Router;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [NavbarComponent],
      imports: [MatIconModule, RouterTestingModule.withRoutes([{ path: '', component: LoginMockComponent }, { path: 'home', component: HomeMockComponent }])]
      //.withRoutes([{ path: 'home', component: DummyComponent }])
    })
      .compileComponents();

    //Creating a instance of component
    //Adding fixture to detect changes
    fixture = TestBed.createComponent(NavbarComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();

    router = TestBed.inject(Router);

    //Calling the LocalStorageMock, when ever the local storage is called
    const localStorageMock = new LocalStorageMock();
    spyOnProperty(window, 'localStorage').and.returnValue(localStorageMock);

    //Calling the SessionStorageMock, when ever the session storage is called
    const sessionStorageMock = new SessionStorageMock();
    spyOnProperty(window, 'sessionStorage').and.returnValue(sessionStorageMock);

  });

  @Component({ template: '' })
  class LoginMockComponent { }

  @Component({ template: '' })
  class HomeMockComponent { }


  //Checking if the instance of the component is created
  it('should create', () => {
    expect(component).toBeTruthy();
  });

  //Adding value to the local storage and session storage, and checing if the .clear() method is called on logout
  it('should clear local storage and session storage', () => {

    localStorage.setItem('key1', 'value1');
    localStorage.setItem('key2', 'value2');
    sessionStorage.setItem('key3', 'value3');

    //Calling the logOut method
    component.logOut();

    //Checing of the local storage and session storage is empty
    expect(localStorage.length).toEqual(0);
    expect(sessionStorage.length).toEqual(0);

  });

  //Some of your tests did a full page reload!

  //HTML

  /*
    //Test case for home router link
    it('should navigate to "/home" when the home icon is clicked', () => {
  
      spyOn(router, 'navigate');
  
      // Try "const homeIconLink = fixture.debugElement.query(By.css('.navbar-brand[href="/home"]'));"
      const homeIconLink = fixture.nativeElement.querySelector('mat-icon');
      homeIconLink.click()
  
      expect(router.navigate).toHaveBeenCalledWith(['/home']);
    });
  */

  /*
    //Checking if the selection method is being called on button click
    it('should call logOut() when the "LOGOUT" link is clicked', () => {
  
      spyOn(component, 'logOut');
  
      const logOutLink = fixture.nativeElement.querySelector('h2');
      expect(logOutLink).toBeTruthy()
  
      logOutLink.click()
  
      expect(component.logOut).toHaveBeenCalled();
  
    });
  
    //Need to add "Test case for '' router link"
  */

});
